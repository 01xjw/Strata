/** A separate, key-protected listener for inference only. Never serves the UI or host APIs. */
import http from 'node:http';
import os from 'node:os';
export function createLocalShare({ handle, hasKey, changed = () => {}, host = '0.0.0.0', port = 8792 }) {
  let listener = null, active = false;
  const address = () => Object.values(os.networkInterfaces()).flat().find(n => n?.family === 'IPv4' && !n.internal)?.address ?? '127.0.0.1';
  const state = () => ({ active, url: active ? `http://${host === '127.0.0.1' ? host : address()}:${listener.address().port}/v1` : null });
  async function start() {
    if (active) return state();
    if (listener) throw new Error('Sharing is already starting.');
    if (!hasKey()) throw new Error('Set an API key before sharing with other devices.');
    listener = http.createServer(async (req, res) => {
      const path = new URL(req.url ?? '/', 'http://localhost').pathname;
      if (!['/v1/models','/v1/chat/completions','/v1/messages'].includes(path)) { res.writeHead(404); res.end('Not found'); return; }
      try { await handle(req, res, path, req.method ?? 'GET'); }
      catch { if (!res.headersSent) res.writeHead(500); res.end('Request failed'); }
    });
    try { await new Promise((resolve,reject) => { listener.once('error',reject); listener.listen(port,host,resolve); }); }
    catch(e) { listener.close(); listener=null; throw e; }
    active=true; changed(); return state();
  }
  async function stop() {
    if (!listener) return state();
    const current=listener; listener=null; active=false;
    current.closeAllConnections(); await new Promise(resolve=>current.close(resolve)); changed(); return state();
  }
  return { state, start, stop };
}
