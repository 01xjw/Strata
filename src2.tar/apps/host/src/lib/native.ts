import { useEffect, useSyncExternalStore } from 'react';
import { api } from './client';
import type { Hardware, RuntimeModels } from './types';
export interface NativeSize {id:string;model:string;about:string;download_gb:number;ram_needed_gb:number;experts_gb:number;on_this_pc:string|null;installed:boolean}
export interface NativeFamily {family:string;title:string;about:string;experimental:boolean;images:boolean;sizes:NativeSize[]}
export interface NativeField {id:string;label:string;group:string;type:'number'|'boolean'|'string'|'enum'|'array';min?:number;max?:number;choices?:string[];hint?:string;supported?:boolean}
export interface NativeJob {id:string;kind:string;guided?:boolean;model?:string;state:'running'|'done'|'error'|'cancelled';startedAt:string;summary:string;error:string|null;details?:string;result:Record<string,any>|null;progress?:Record<string,any>|null}
export interface NativeInstance {id:string;apiModelId:string;model:string;label:string;aliases?:string[];vision?:boolean;resourceProfile?:'work'|'performance'|null;context?:number;port:number;gpus:number[];status:'loading'|'ready'|'unloading'|'error';phase:string;loadedAt:string;error:string|null;metrics:Record<string,any>|null}
export interface NativeState {available:boolean;repo:string;downloadDirectory?:string;version?:string|null;summary:string;error:string|null;catalog:{families:NativeFamily[];contexts:number[];recommendation:{family:string|null;model:string|null;context?:number;why?:string};context_note:string}|null;installed:{models:{model:string;config:string;model_name:string;ready:boolean;/** The picture-reading files are on this computer (notes-split-agent8.md, item 8). */visionPrepared?:boolean;context?:number;kv?:string;images?:string;visionEnabled?:boolean;visionDevice?:string;lowRamMode?:string;resourceProfile?:'work'|'performance';dataFolder?:string;diskGb?:number;diskBytes?:number;missing_files?:string[]}[];data_folder:string;engine:{version:string|null}}|null;hardware:{ram_gb:number;gpus:{index:number;name:string;vram_gb:number;usable:boolean}[]}|null;fields:NativeField[];instances:NativeInstance[];defaultId:string|null;jobs:NativeJob[];capabilities:{responses?:boolean;updates:boolean;rollback:boolean;calibration:boolean;componentUpdates?:boolean}}
let state:NativeState|null=null,timer:ReturnType<typeof setInterval>|null=null,reading:Promise<void>|null=null;
const listeners=new Set<()=>void>();
let again=false;
/** A forced refresh (after an action) never joins a read that began before the action: that read cannot know about the new job. It waits for it, then reads again. */
export function refreshNative(force=false):Promise<void>{if(reading){if(!force)return reading;if(again)return reading;again=true;return reading.then(()=>{again=false;return refreshNative(true);});}reading=api.get<NativeState>(`/api/native${force?'?refresh=1':''}`).then(value=>{if(state&&JSON.stringify(state)===JSON.stringify(value))return;state=value;listeners.forEach(fn=>fn());}).catch(error=>{if(state){state={...state,error:error.message,instances:state.instances.map(i=>({...i,metrics:null,phase:'unavailable'}))};listeners.forEach(fn=>fn());}}).finally(()=>{reading=null;});return reading;}
export function useNative(){const value=useSyncExternalStore(fn=>{listeners.add(fn);return()=>listeners.delete(fn);},()=>state);useEffect(()=>{void refreshNative();if(!timer)timer=setInterval(()=>void refreshNative(),2500);return()=>{if(!listeners.size&&timer){clearInterval(timer);timer=null;}};},[]);return value;}
export const nativeState=()=>state;
/** Connection-list projection only; memory reservations are not inferred. */
export function nativeRouting(native:NativeState|null,hardware:Hardware|null):RuntimeModels|null{
 if(!native?.instances.length)return null;
 return {revision:Date.now(),mode:'real',capabilities:{multipleModels:true,deviceAssignment:true},defaultId:native.defaultId,instances:native.instances.filter(i=>i.status==='ready').map(i=>({id:i.id,apiModelId:i.apiModelId,variantId:i.model,family:i.label,name:i.model,quant:i.model,loadedAt:i.loadedAt,status:'ready',phase:i.phase as RuntimeModels['instances'][number]['phase'],active:i.metrics?.live?.running??0,queued:i.metrics?.live?.queued??0,prompt:{done:0,total:0,pct:0},outputTps:i.metrics?.live?.tok_s??0,promptTps:i.metrics?.live?.prefill_tok_s_mean??0,context:{usedTokens:0,maxTokens:i.metrics?.engine?.max_context??i.context??0,pct:0},gpuIds:i.gpus.map(index=>{const g=hardware?.gpus.find(g=>g.index===index);return g?.id??`${g?.vendor??'native'}:${index}`;}),memory:{context:i.metrics?.engine?.max_context??i.context??0,ramGb:0,gpuGb:0,spillGb:0,reserveGb:0,totalGb:0,devices:[]}})),memory:{ramGb:0,budgetGb:0,reserveGb:0,totalGb:0,fits:true,devices:[]}};
}
export async function nativeAction<T=unknown>(path:string,body:unknown={}){const result=await api.post<T>(`/api/native/${path}`,body);
 // A started operation is a job: show it at once instead of waiting for the next read (the owner saw download progress only after switching tabs).
 const job=result as unknown as NativeJob|undefined;
 if(state&&job&&typeof job.id==='string'&&path==='operations'&&!state.jobs.some(j=>j.id===job.id)){state={...state,jobs:[...state.jobs,job]};listeners.forEach(fn=>fn());}
 await refreshNative(true);return result;}

export {nativeVersionLabel} from './native-catalog';
